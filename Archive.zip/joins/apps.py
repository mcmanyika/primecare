from django.apps import AppConfig


class JoinsConfig(AppConfig):
    name = 'joins'
