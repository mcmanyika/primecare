/**
 * @license Highcharts JS v7.2.0 (2019-09-03)
 * @module highcharts/themes/dark-unica
 * @requires highcharts
 *
 * (c) 2009-2019 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../themes/dark-unica.js';
